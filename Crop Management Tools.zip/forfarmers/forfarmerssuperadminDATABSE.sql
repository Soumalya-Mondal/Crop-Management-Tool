-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2022 at 09:23 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `forfarmerssuperadmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminDBID` int(10) NOT NULL,
  `adminID` varchar(20) NOT NULL,
  `adminPASSWORD` varchar(255) NOT NULL,
  `adminNAME` varchar(100) NOT NULL,
  `adminGENDER` varchar(10) NOT NULL,
  `adminPHONE` varchar(15) NOT NULL,
  `adminEMAIL` varchar(100) NOT NULL,
  `adminAADHAAR` varchar(12) NOT NULL,
  `adminCREATETIME` varchar(50) NOT NULL,
  `adminCREATENAME` varchar(100) NOT NULL,
  `adminCREATEID` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminDBID`, `adminID`, `adminPASSWORD`, `adminNAME`, `adminGENDER`, `adminPHONE`, `adminEMAIL`, `adminAADHAAR`, `adminCREATETIME`, `adminCREATENAME`, `adminCREATEID`) VALUES
(1, 'ADM/22-02/0001', '$2y$10$S5PkbChxHDnTyZl/YhrRbeD4Vbf//VslFqBh21BthcIS8JRb3rSOy', 'Soumalya Mondal', 'Male', '918961805558', 'iamsoumalya007@hotmail.com', '456912345236', '2022-02-07 01:43:40', 'Soumalya Mondal', 'SADM/22-02/0001');

-- --------------------------------------------------------

--
-- Table structure for table `otp_check`
--

CREATE TABLE `otp_check` (
  `id` int(100) NOT NULL,
  `otp` varchar(6) NOT NULL,
  `email` varchar(100) NOT NULL,
  `expired` int(1) NOT NULL,
  `createtime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `id` int(10) NOT NULL,
  `issueID` varchar(50) NOT NULL,
  `issueMSG` text NOT NULL,
  `issueRESPONSE` text NOT NULL,
  `issueACTIVE` varchar(10) NOT NULL,
  `adminID` varchar(20) NOT NULL,
  `issueTIME` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sadmin`
--

CREATE TABLE `sadmin` (
  `sadminDBID` int(10) NOT NULL,
  `sadminID` varchar(20) NOT NULL,
  `sadminNAME` varchar(100) NOT NULL,
  `sadminPHONE` varchar(20) NOT NULL,
  `sadminEMAIL` varchar(100) NOT NULL,
  `sadminGENDER` varchar(10) NOT NULL,
  `sadminPASSWORD` varchar(255) NOT NULL,
  `sadminCREATE` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sadmin`
--

INSERT INTO `sadmin` (`sadminDBID`, `sadminID`, `sadminNAME`, `sadminPHONE`, `sadminEMAIL`, `sadminGENDER`, `sadminPASSWORD`, `sadminCREATE`) VALUES
(1, 'SADM/22-02/0001', 'Soumalya Mondal', '+918961805558', 'iamsoumalya007@hotmail.com', 'Male', '$2y$10$pOp0ONvgDe8GDbXA1hNDxOJAXHIxJC2UJ3vH4JF0pDAk1K8BLI5Yq', '2022-02-03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminDBID`),
  ADD UNIQUE KEY `adminEMAIL` (`adminEMAIL`),
  ADD UNIQUE KEY `adminID` (`adminID`),
  ADD UNIQUE KEY `adminAADHAAR` (`adminAADHAAR`);

--
-- Indexes for table `otp_check`
--
ALTER TABLE `otp_check`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sadmin`
--
ALTER TABLE `sadmin`
  ADD PRIMARY KEY (`sadminDBID`),
  ADD UNIQUE KEY `sadminEMAIL` (`sadminEMAIL`),
  ADD UNIQUE KEY `sadminID` (`sadminID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminDBID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `otp_check`
--
ALTER TABLE `otp_check`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sadmin`
--
ALTER TABLE `sadmin`
  MODIFY `sadminDBID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
