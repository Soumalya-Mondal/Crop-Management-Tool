<div class="container-fluid bg-dark text-light fixed-bottom">
    <p class="text-center mb-0">&copy;ForFarmers! 2021-30. All Rights Reserved.&reg;</p>
</div>