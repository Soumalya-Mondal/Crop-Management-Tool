-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2022 at 09:23 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crop-sensor`
--

-- --------------------------------------------------------

--
-- Table structure for table `senor-list`
--

CREATE TABLE `senor-list` (
  `id` int(10) NOT NULL,
  `deviceID` varchar(15) NOT NULL,
  `deviceCONTACT` varchar(20) NOT NULL,
  `deviceCONTACTPERSON` varchar(50) NOT NULL,
  `deviceLOCATION` varchar(50) NOT NULL,
  `deviceADDRESS` varchar(255) NOT NULL,
  `devicePINCODE` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `senor-list`
--

INSERT INTO `senor-list` (`id`, `deviceID`, `deviceCONTACT`, `deviceCONTACTPERSON`, `deviceLOCATION`, `deviceADDRESS`, `devicePINCODE`) VALUES
(1, 'AN0001', '+915632149856', 'Amber Lawrence', 'Andaman and Nicobar', '25/2, Mrr Lane, Behind Hotel King, S J P Road', '560002'),
(2, 'AN0002', '+914569325614', 'Randolf Chad', 'Andaman and Nicobar', '122, Prabhat Complex, Sarita Bldg, Near Toll Naka, Dahisar', '400068'),
(3, 'AN0003', '+914569321469', 'Belinda Ambrose', 'Andaman and Nicobar', 'Shop No 1, Sarita Bhavan, Mamledarwadi, Malad (west)', '400064'),
(4, 'AN0004', '+914569325614', 'Celeste Therese', 'Andaman and Nicobar', '1232/80,1st Main, Loha Bhavan, Magadi Chord Road', '560079'),
(5, 'AP0001', '+914569852314', 'Brady Carla', 'Andhra Pradesh', '19 Maya Plaza, T Nagar', '600017'),
(6, 'AP0002', '+914569325614', 'Ursula Sherri', 'Andhra Pradesh', 'H 86, Ashok Vihar', '110052'),
(7, 'WB0001', '+915623145698', 'Duke Arden', 'West Bengal', 'Shop No 1, Gr Flr, United Chambers, Grant Road, Nr Shalimar Cinema, Grant Road', '400007'),
(8, 'WB0002', '+914563987436', 'Daryl Cathryn', 'West Bengal', '59/a, Maker Arcade, Cuffe Parade', '400005');

-- --------------------------------------------------------

--
-- Table structure for table `state-list`
--

CREATE TABLE `state-list` (
  `id` int(5) NOT NULL,
  `stateNAME` varchar(50) NOT NULL,
  `stateCONTACT` varchar(20) NOT NULL,
  `stateCONTACTNAME` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `state-list`
--

INSERT INTO `state-list` (`id`, `stateNAME`, `stateCONTACT`, `stateCONTACTNAME`) VALUES
(1, 'Andaman and Nicobar', '+916748961727', 'Shirley Eady'),
(2, 'Andhra Pradesh', '+917477619082', 'Katheryne Blackbourne'),
(3, 'Arunachal Pradesh', '+916128436700', 'Leilah Everett'),
(4, 'Assam', '+918079673087', 'Roland Spear'),
(5, 'Bihar', '+916127961648', 'Emmitt Gold'),
(6, 'Chandigarh', '+916127918454', 'Lorelei Christophers'),
(7, 'Chhattisgarh', '+916102047488', 'Comfort Tennison'),
(8, 'Dadra and Nagar Haveli', '+918079528601', 'Earle Beckett'),
(9, 'Daman and Diu', '+916127996439', 'Lance Tanner'),
(10, 'Delhi', '+917323928926', 'Jeremy Garner'),
(11, 'Goa', '+918917394389', 'Zella Stamp'),
(12, 'Gujarat', '+916718725622', 'Leone Osborne'),
(13, 'Haryana', '+916127919969', 'Bartholomew Tate'),
(14, 'Himachal Pradesh', '+916127992025', 'Rex Aaron'),
(15, 'Jammu & Kashmir', '+916519820864', 'Rodney Thwaite'),
(16, 'Jharkhand', '+916127990610', 'Webster Glass'),
(17, 'Karnataka', '+918076148442', 'Mackenzie John'),
(18, 'Kerala', '+917287143392', 'Jeremy Park'),
(19, 'Lakshadweep', '+916127958224', 'Dominick Sanderson'),
(20, 'Madhya Pradesh', '+917317734459', 'Rafferty Blackman'),
(21, 'Maharashtra', '+916127962185', 'Quentin Elvis'),
(22, 'Manipur', '+919052216849', 'Clarence Sidney'),
(23, 'Meghalaya', '+917287006755', 'Ellis Morce'),
(24, 'Mizoram', '+916127952866', 'Paulina Cookson'),
(25, 'Nagaland', '+916128377017', 'Micheal Bernard'),
(26, 'Orissa', '+917283491940', 'Christian Devine'),
(27, 'Puducherry', '+918847069581', 'Aletha Quincy'),
(28, 'Punjab', '+918917692516', 'Edwin Rowe'),
(29, 'Rajasthan', '+916127980496', 'Lynwood Headley'),
(30, 'Sikkim', '+918847683679', 'Denton Tyson'),
(31, 'Tamil Nadu', '+917196959057', 'Bryson Saylor'),
(32, 'Telangana', '+918066864640', 'Deeann Chaplin'),
(33, 'Tripura', '+916571052245', 'Lloyd Spalding'),
(34, 'Uttar Pradesh', '+916518416891', 'Odelia Janson'),
(35, 'Uttarakhand', '+918167724204', 'Garnett Ellery'),
(36, 'West Bengal', '+918707548395', 'Amanda Backus');

-- --------------------------------------------------------

--
-- Table structure for table `temp-humid-sensor`
--

CREATE TABLE `temp-humid-sensor` (
  `id` int(50) NOT NULL,
  `deviceID` varchar(10) NOT NULL,
  `date` varchar(15) NOT NULL,
  `time` varchar(15) NOT NULL,
  `temp` varchar(5) NOT NULL,
  `humid` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `temp-humid-sensor`
--

INSERT INTO `temp-humid-sensor` (`id`, `deviceID`, `date`, `time`, `temp`, `humid`) VALUES
(1, 'AN0001', '29-01-2022', '13:51:02', '23.90', '56.00'),
(2, 'AN0001', '29-01-2022', '13:51:07', '23.90', '57.00'),
(3, 'AN0001', '29-01-2022', '13:51:13', '23.90', '57.00'),
(4, 'AN0001', '29-01-2022', '13:51:19', '23.90', '57.00'),
(5, 'AN0001', '29-01-2022', '13:51:24', '23.90', '57.00'),
(6, 'AN0001', '29-01-2022', '13:51:30', '23.90', '57.00'),
(7, 'AN0002', '29-01-2022', '13:52:01', '23.90', '57.00'),
(8, 'AN0002', '29-01-2022', '13:52:07', '23.90', '57.00'),
(9, 'AN0002', '29-01-2022', '13:52:12', '23.90', '57.00'),
(10, 'AN0002', '29-01-2022', '13:52:18', '23.90', '57.00'),
(11, 'AN0002', '29-01-2022', '13:52:24', '23.90', '57.00'),
(12, 'AN0002', '29-01-2022', '13:52:29', '23.90', '56.00'),
(13, 'AN0002', '29-01-2022', '13:52:35', '23.90', '56.00'),
(14, 'AN0003', '29-01-2022', '13:53:03', '23.90', '56.00'),
(15, 'AN0003', '29-01-2022', '13:53:08', '23.90', '57.00'),
(16, 'AN0003', '29-01-2022', '13:53:14', '23.90', '57.00'),
(17, 'AN0003', '29-01-2022', '13:53:20', '24.00', '57.00'),
(18, 'AN0003', '29-01-2022', '13:53:25', '24.00', '56.00'),
(19, 'AN0003', '29-01-2022', '13:53:31', '24.00', '56.00'),
(20, 'AN0004', '29-01-2022', '13:54:00', '24.00', '56.00'),
(21, 'AN0004', '29-01-2022', '13:54:06', '24.00', '56.00'),
(22, 'AN0004', '29-01-2022', '13:54:12', '24.00', '56.00'),
(23, 'AN0004', '29-01-2022', '13:54:17', '24.00', '56.00'),
(24, 'AN0004', '29-01-2022', '13:54:23', '24.00', '56.00'),
(25, 'AN0004', '29-01-2022', '13:54:28', '24.00', '56.00'),
(26, 'AN0004', '29-01-2022', '13:54:34', '24.00', '56.00'),
(27, 'AP0001', '29-01-2022', '13:55:03', '24.00', '56.00'),
(28, 'AP0001', '29-01-2022', '13:55:09', '23.90', '56.00'),
(29, 'AP0001', '29-01-2022', '13:55:14', '24.00', '56.00'),
(30, 'AP0001', '29-01-2022', '13:55:20', '24.00', '56.00'),
(31, 'AP0001', '29-01-2022', '13:55:25', '24.00', '56.00'),
(32, 'AP0002', '29-01-2022', '13:55:55', '24.00', '56.00'),
(33, 'AP0002', '29-01-2022', '13:56:01', '24.00', '56.00'),
(34, 'AP0002', '29-01-2022', '13:56:07', '24.00', '56.00'),
(35, 'AP0002', '29-01-2022', '13:56:12', '24.00', '56.00'),
(36, 'AP0002', '29-01-2022', '13:56:18', '24.00', '56.00'),
(37, 'WB0001', '29-01-2022', '13:56:48', '24.00', '57.00'),
(38, 'WB0001', '29-01-2022', '13:56:54', '24.00', '55.00'),
(39, 'WB0001', '29-01-2022', '13:56:59', '24.00', '55.00'),
(40, 'WB0001', '29-01-2022', '13:57:05', '24.00', '55.00'),
(41, 'WB0001', '29-01-2022', '13:57:10', '24.00', '55.00'),
(42, 'WB0001', '29-01-2022', '13:57:16', '24.10', '55.00'),
(43, 'WB0002', '29-01-2022', '13:57:44', '24.10', '55.00'),
(44, 'WB0002', '29-01-2022', '13:57:50', '24.00', '55.00'),
(45, 'WB0002', '29-01-2022', '13:57:55', '24.00', '55.00'),
(46, 'WB0002', '29-01-2022', '13:58:01', '24.00', '54.00'),
(47, 'WB0002', '29-01-2022', '13:58:07', '24.00', '54.00'),
(48, 'WB0002', '29-01-2022', '13:58:12', '24.00', '55.00'),
(49, 'WB0002', '29-01-2022', '13:58:18', '24.10', '55.00'),
(50, 'WB0002', '29-01-2022', '13:58:23', '24.10', '55.00'),
(51, 'WB0002', '29-01-2022', '13:58:29', '24.10', '55.00'),
(52, 'WB0002', '29-01-2022', '13:58:34', '24.10', '55.00'),
(53, 'WB0002', '29-01-2022', '13:58:40', '24.10', '55.00'),
(54, 'WB0002', '29-01-2022', '13:58:45', '24.10', '55.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `senor-list`
--
ALTER TABLE `senor-list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `state-list`
--
ALTER TABLE `state-list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `temp-humid-sensor`
--
ALTER TABLE `temp-humid-sensor`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `senor-list`
--
ALTER TABLE `senor-list`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `state-list`
--
ALTER TABLE `state-list`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `temp-humid-sensor`
--
ALTER TABLE `temp-humid-sensor`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
