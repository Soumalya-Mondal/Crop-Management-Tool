<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="resource/bootstrapcss/bootstrap.min.css">
    <link rel="stylesheet" href="resource/icon/css/font-awesome.min.css">
    <link rel="icon" href="content/icon/icon.png">
    <title>ForFarmers!</title>
    <style>
        #all{
            background-image: url('content/image/bg.jpg');
            height: 100vh;
            
        }
    </style>
</head>

<body id="all">
    <!-- Header START -->
    <?php
    include 'partials/_header.php';
    ?>
    <!-- Header END -->

    <!-- Content START -->
    <!-- Header START -->
    <div class="container my-5" style="color: white;">
        <h2 class="text-center">Welcome To ForFarmers!</h2>
    </div>
    <!-- Header END -->
    <!-- MainSection START -->
    <div class="container my-5 mb-5">
        <div class="row my-3">
            <div class="col-md-4 my-2">
                <div class="card mx-auto shadow-lg bg-body rounded" style="width: 20rem;">
                    <div class="card-body">
                        <h5 class="card-title text-center user-select-none">Local Panel.</h5>
                        <p class="card-text text-break user-select-none">Lorem ipsum dolor sit amet consectetur adipisicing elit. Non voluptatem dolores totam rerum nostrum sapiente explicabo in molestias aspernatur dolorem.</p>
                        <a href="#" class="d-grid btn" style="background-color: #7bfaf4; color: black;">Go To Temperature Panel</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 my-2">
                <div class="card mx-auto shadow-lg bg-body rounded" style="width: 20rem;">
                    <div class="card-body">
                        <h5 class="card-title text-center user-select-none">Farmer Panel.</h5>
                        <p class="card-text text-break user-select-none">Lorem ipsum dolor sit amet consectetur adipisicing elit. Non voluptatem dolores totam rerum nostrum sapiente explicabo in molestias aspernatur dolorem.</p>
                        <a href="partials/_farmerpanel.php?panel=farmer" class="d-grid btn" style="background-color: #7bfaf4; color: black;">Go To Farmer Panel</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 my-2">
                <div class="card mx-auto shadow-lg bg-body rounded" style="width: 20rem;">
                    <div class="card-body">
                        <h5 class="card-title text-center user-select-none">Admin Panel.</h5>
                        <p class="card-text text-break user-select-none">Lorem ipsum dolor sit amet consectetur adipisicing elit. Non voluptatem dolores totam rerum nostrum sapiente explicabo in molestias aspernatur dolorem.</p>
                        <a href="partials/_adminpanel.php?panel=admin" class="d-grid btn" style="background-color: #7bfaf4; color: black;">Go To Admin Panel</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- MainSection END -->
    <!-- Content END -->

    <!-- Footer START -->
    <?php
    include 'partials/_footer.php';
    ?>
    <!-- Footer END -->
    <script src="resource/bootstrapjs/bootstrap.bundle.min.js"></script>

</body>

</html>