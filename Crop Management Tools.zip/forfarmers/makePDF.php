<?php
    session_start();
    include 'partials/_dbconnect.php';
    include 'resource/phpqrcode/qrlib.php';
    include 'resource/fpdf/fpdf.php';

    function farmer_ID_qrcode($farmerID){
        $fileDIR= 'farmerCARD/farmerIDtempQRCODE/';
        $codeCONTENT= $farmerID;

        $fileNAME= $farmerID.'.png';

        $filePATH= $fileDIR.$fileNAME;

        if(file_exists($filePATH)){
            unlink($filePATH);
            QRcode::png($codeCONTENT, $filePATH,  QR_ECLEVEL_L, 4);
        }
        else{
            QRcode::png($codeCONTENT, $filePATH,  QR_ECLEVEL_L, 4);
        }
    }

    function farmer_ID_pdf($farmerID, $farmerNAME, $farmerAADHAAR, $farmerPICTURE){
        farmer_ID_qrcode($farmerID);

        $farmerQRDIR= 'farmerCARD/farmerIDtempQRCODE/'.$farmerID.'.png';
        $farmerPDFDIR= 'farmerCARD/farmerIDPDF/';

        $pdf= new FPDF('L', 'mm', array(86, 54));
        $pdf->SetMargins(0, 0, 0);
        $pdf->AddPage();
        $pdf->SetFont('Times', 'B', 12);

        $pdf->Image('resource/PVCTemplate.png', 0, 0, 86, 54);

        $pdf->SetXY(2, 14);
        $pdf->Cell(57, 0, 'ID: '.$farmerID, 0, 'L', false, '');

        $pdf->SetXY(2, 20);
        $pdf->Cell(57, 0, 'Name: '.$farmerNAME, 0, 'L', false, '');

        $pdf->SetXY(2, 26);
        $pdf->Cell(57, 0, 'Aadhaar: '.$farmerAADHAAR, 0, 'L', false, '');

        $pdf->Image($farmerPICTURE, 58, 12, 24, 24, '', '');
        $pdf->Image($farmerQRDIR, 0, 30, 20, 20, '', '');

        $pdf->Output($farmerPDFDIR.$farmerID.'.pdf', 'F');
    }

    if($_SERVER['REQUEST_METHOD']== 'POST' && isset($_SESSION['login']) && $_SESSION['login']== true){
        if(isset($_POST['FARMERid'])){
            $farmerID= $_POST['FARMERid'];
            $farmerAADHAAR= $_POST['FARMERaadhaar'];
            $adminPASSWORD= $_POST['adminPASSWORD'];
            $adminID= $_SESSION['adminID'];
        }
    }
    
    $admincheckSQL= "SELECT * FROM `admin` WHERE adminID= '$adminID'";
    $admincheckRESULT= mysqli_query($conn, $admincheckSQL);
    $admincheckROWS= mysqli_num_rows($admincheckRESULT);

    if($admincheckROWS== 1){
        $admincheckROW= mysqli_fetch_assoc($admincheckRESULT);
            if(password_verify($adminPASSWORD, $admincheckROW['adminPASSWORD'])){
                $farmergetdetailsSQL= "SELECT * FROM `farmer` WHERE farmerID= '$farmerID' AND farmerAADHAAR= '$farmerAADHAAR'";
                $farmergetdetailsRESULT= mysqli_query($conn, $farmergetdetailsSQL);
                $farmergetdetailsROW= mysqli_fetch_assoc($farmergetdetailsRESULT);

                $farmergetdetailsID= $farmergetdetailsROW['farmerID'];
                $farmergetdetailsNAME= $farmergetdetailsROW['farmerNAME'];
                $farmergetdetailsAADHAAR= $farmergetdetailsROW['farmerAADHAAR'];
                $farmergetdetailsPICTURE= $farmergetdetailsROW['farmerPICTURE'];

                farmer_ID_pdf($farmergetdetailsID, $farmergetdetailsNAME, $farmergetdetailsAADHAAR, $farmergetdetailsPICTURE);

                $farmerQRDIR= 'farmerCARD/farmerIDtempQRCODE/'.$farmergetdetailsID.'.png';
                unlink($farmerQRDIR);

                $printcountSQL= "SELECT farmerPRINTCOUNT FROM farmer WHERE farmerID='$farmergetdetailsID' ORDER BY farmerPRINTCOUNT DESC LIMIT 1";
                $printcountRESULT= mysqli_query($conn, $printcountSQL);
                $printcountROWS= mysqli_num_rows($printcountRESULT);

                if($printcountROWS== 1){
                    $printCOUNT= mysqli_fetch_assoc($printcountRESULT);
                    $OLDprintCOUNT= $printCOUNT['farmerPRINTCOUNT'];
                    $NEWprintCOUNT= $OLDprintCOUNT+ 1;

                    $updateprintcountSQL= "UPDATE `farmer` SET `farmerPRINTCOUNT` = '$NEWprintCOUNT' WHERE `farmer`.`farmerID` = '$farmergetdetailsID'";
                    mysqli_query($conn, $updateprintcountSQL);
                }
                header('Location: /farm/partials/_farmermanage.php?panel=admin&print=true');
            }
            else{
                header('Location: /farm/partials/_farmermanage.php?panel=admin&loginf=true');
            }
    }
?>