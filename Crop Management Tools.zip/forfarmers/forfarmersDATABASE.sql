-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2022 at 09:23 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `forfarmers`
--

-- --------------------------------------------------------

--
-- Table structure for table `farmer`
--

CREATE TABLE `farmer` (
  `farmerDBID` int(11) NOT NULL,
  `farmerID` varchar(25) NOT NULL,
  `farmerNAME` varchar(100) NOT NULL,
  `farmerADDRESS` varchar(500) NOT NULL,
  `farmerSTATE` varchar(100) NOT NULL,
  `farmerPINCODE` varchar(10) NOT NULL,
  `farmerAADHAAR` varchar(20) NOT NULL,
  `farmerPICTURE` varchar(255) NOT NULL,
  `farmerGENDER` varchar(10) NOT NULL,
  `farmerDOB` date NOT NULL,
  `farmerACTIVE` int(2) NOT NULL,
  `farmerPASSWORD` varchar(255) NOT NULL,
  `farmerPRINTCOUNT` int(10) NOT NULL,
  `admincreatedID` varchar(20) NOT NULL,
  `admincreatedNAME` varchar(100) NOT NULL,
  `farmerCREATE` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `farmer`
--

INSERT INTO `farmer` (`farmerDBID`, `farmerID`, `farmerNAME`, `farmerADDRESS`, `farmerSTATE`, `farmerPINCODE`, `farmerAADHAAR`, `farmerPICTURE`, `farmerGENDER`, `farmerDOB`, `farmerACTIVE`, `farmerPASSWORD`, `farmerPRINTCOUNT`, `admincreatedID`, `admincreatedNAME`, `farmerCREATE`) VALUES
(1, 'WB2202060741290001', 'Soumalya Mondal', '547/2 Rabindranath Tagore Road, Kolkata', 'West Bengal', '700077', '456912343265', 'partials/farmerPICTURE/Soumalya Mondal456912343265.jpeg', 'Male', '2022-01-31', 0, '$2y$10$G5ol9bRiwLyheW5HXHAQQeXgXm5CaTMT2wWQE14ybKSXLQXPlDQP6', 0, 'ADM/22-02/0001', 'Soumalya Mondal', '2022-02-06'),
(2, 'DD2202060741560002', 'Debasis Mandal', '24/2 K.C Paul Ghosh Road', 'Daman and Diu', '700258', '896512347456', 'partials/farmerPICTURE/Debasis Mandal896512347456.jpeg', 'Male', '2022-02-01', 0, '$2y$10$xFagn7La9djkLwg1Z569nekcXDf.rupssH0jCQxXqN8FvnFokOQvm', 0, 'ADM/22-02/0001', 'Soumalya Mondal', '2022-02-06'),
(3, 'RJ2202060742180003', 'Prosenjit Adhikary', '20/25 Raja Apurba Krishna Lane', 'Rajasthan', '158105', '569812341569', 'partials/farmerPICTURE/Prosenjit Adhikary569812341569.jpeg', 'Male', '2022-02-02', 0, '$2y$10$VVlxDu4TKonyYTclkGqTuO4Wm69r4v2gF94eeCTfmy6OxHBHb8E4u', 0, 'ADM/22-02/0001', 'Soumalya Mondal', '2022-02-06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `farmer`
--
ALTER TABLE `farmer`
  ADD PRIMARY KEY (`farmerDBID`),
  ADD UNIQUE KEY `farmerID` (`farmerID`),
  ADD UNIQUE KEY `farmerAADHAAR` (`farmerAADHAAR`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `farmer`
--
ALTER TABLE `farmer`
  MODIFY `farmerDBID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
